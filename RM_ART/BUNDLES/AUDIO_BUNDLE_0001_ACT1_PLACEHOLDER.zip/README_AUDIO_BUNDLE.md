# AUDIO_BUNDLE_0001_ACT1_PLACEHOLDER

Este bundle é um **esqueleto** (sem áudio final).

Regras:
- Produção final: **apenas assets próprios/originais**.
- Organizar por pastas do RPG Maker XP: Audio/BGM, Audio/BGS, Audio/ME, Audio/SE.
- Nomes de arquivos devem bater com FileStem/Format definidos em CORE.AUDIO_CUES.

Gerado em: 2025-12-30T01:27:55Z
