
# Documento de Design de Jogo (GDD)  
## Adventures Unleashed: Rave Masters – Versão 0.2 (Revisada em Português)

---

## 1. Visão Geral

**Título de trabalho:** Adventures Unleashed: Rave Masters  
**Gênero:** RPG tático em turnos com foco em exploração, progressão profunda de personagem e modos cooperativos/competitivos (PvE/PvP).

**Referências de design (sensação e sistemas):**
- Runescape / Guild Wars 2 / Minecraft – exploração, coleta, profissões e sensação de mundo persistente.
- Pokémon (jogos principais + cenário competitivo) – combate em turnos, importância de ordem de ação, status, buffs/debuffs e leitura estratégica.
- MMORPGs – estrutura de conteúdo de fim de jogo (raids, eventos sazonais, arena PvP, rankings).

**Objetivo de experiência:**  
Permitir que o jogador comece em um vilarejo simples, enfrente ameaças crescentes em um mundo amplo e chegue a um estágio avançado com:
- classes especializadas,
- grande variedade de habilidades,
- equipamentos raros,
- e confrontos complexos em raids e arena.

O projeto é concebido como base para expansão contínua (novas classes, regiões, sistemas).

---

## 2. Estrutura de Jogo e Progressão

### 2.1. Mundo

- Mundo amplo, dividido em regiões com:
  - vilarejos, cidades e acampamentos,
  - áreas selvagens e dungeons,
  - calamidades e eventos específicos.
- O jogador desbloqueia novos pontos à medida que:
  - avança na campanha,
  - conclui quests principais,
  - supera desafios de dificuldade crescente.

### 2.2. Ciclo de progressão

- **Início de jogo:** vilarejo inicial, combate básico, introdução a sistemas de status, equipamentos, teleporte e à trama do desaparecimento de Rose e da Árvore Guardiã.  
- **Meio de jogo:** ampliação de mapa, novas vilas/cidades, acesso a dungeons intermediárias, equipamentos mais raros e maior variedade de builds.  
- **Conteúdo avançado:** raids, calamidades de alto nível, arena PvP estruturada, eventos sazonais e confrontos contra entidades de grande escala (dragões, demônios, anjos, etc.).

---

## 3. Sistema de Combate

### 3.1. Estrutura

- Combate **em turnos**, com peso em:
  - **AGI** (ordem de ação),
  - **Precisão** e **Evasão**,
  - buffs, debuffs e controle.
- O jogador controla um **personagem principal**, podendo chamar aliados, invocações e outros auxiliares conforme progride.

### 3.2. Posições

Formação em três linhas (até 9 unidades de cada lado):

- Frente (3): foco em combate corpo a corpo e absorção de dano.  
- Meio (3): função híbrida (suporte, dano à distância, proteção da retaguarda).  
- Retaguarda (3): ataques à distância, conjuração e suporte.

### 3.3. Ordem de turnos

- Calculada a partir de AGI, com pequena variação aleatória controlada.
- Em PvE offline, o turno não progride sem ação do jogador.
- Em modos online (PvP/raids), existe limite de tempo por turno.

### 3.4. Movimento

- Posição básica é fixa.
- Habilidades específicas permitem:
  - avanço/recuo,
  - troca de posição com aliados ou inimigos,
  - aproximações instantâneas (por exemplo, Rogue).

### 3.5. Morte e punição

- Conteúdo padrão:
  - acesso a itens de cura,
  - mortes ocasionais geram perda de recursos e tempo, não punição extrema.
- Conteúdo avançado:
  - restrições de ressurgimento,
  - penalidade em recompensas,
  - condições especiais de vitória/derrota.

### 3.6. Slots de habilidades

Slots disponíveis:

- Habilidade de Suporte (fixa como suporte),
- Habilidade A,
- Habilidade B,
- Habilidade C,
- Habilidade S (slot especial),
- Habilidade Ultimate.

Regras:
- Slots Suporte, A, B, C e S possuem **níveis de 1 a 3**; o nível do slot determina a força/versão da habilidade equipada.
- O slot **S** é considerado nível 3 por padrão.
- O slot S é desbloqueado em um marco de nível (proposta: nível 80).
- Habilidades podem ser trocadas livremente entre slots fora de combate.

### 3.7. Ultimates

- Cada classe possui uma lista própria de Ultimates.
- O personagem pode aprender várias, mas só **uma** pode estar equipada.
- Características:
  - custo alto de SP,
  - tempo de recarga,
  - impacto elevado (dano, controle, suporte).

---

## 4. Atributos e Status

### 4.1. Atributos

Seis atributos principais (conforme FICHA RPG) afetam:

- HP, SP,
- dano físico e mágico,
- defesas,
- precisão/evasão,
- chance e eficácia de status.

(As fórmulas detalhadas permanecem no documento técnico de balanceamento.)

### 4.2. Status derivados

Incluem, entre outros:

- Evasiva (EVA),
- Poder Físico / Poder Mágico,
- Defesas física e mágica,
- Precisões física e mágica,
- Crítico físico e mágico,
- Resistência a Status Negativo,
- parâmetros de duração e eficácia de status negativos e positivos.

### 4.3. Status de sorte

- **Gold Find** – modifica quantidade de ouro obtida.  
- **Item Find** – modifica quantidade de itens/materiais obtidos.  
- **Magical Item Find** – altera chance de itens de maior raridade.

---

## 5. Sistema de Nível

### 5.1. Nível de personagem

- **Mono Classe:**
  - Nível máximo 100.
  - Foco em uma única árvore de classe.

- **Dual Classe:**
  - Nível máximo 180.
  - Combina duas árvores de classe, com progressão mais longa e mais complexa.

A escolha entre Mono/Dual é realizada na criação de personagem e é definitiva.

### 5.2. Soft Skills / Profissões

- Habilidades secundárias inspiradas em Runescape (Mineração, Lenhador, Culinária, etc.).
- Cada profissão possui nível independente até 100.
- Desbloqueiam:
  - acesso a materiais melhores,
  - receitas de fabricação,
  - interações especiais com o mundo.

---

## 6. Classes

### 6.1. Classes iniciais

10 classes jogáveis na versão inicial:

1. Knight  
2. Warrior  
3. Rogue (Male)  
4. Ranger  
5. Pyromancer  
6. Cryomancer  
7. Druid  
8. Cleric  
9. Berserker  
10. Shaman  

Podem ser usadas em configuração Mono ou Dual Classe.

### 6.2. Função e fantasia (resumo)

- **Knight:** defensor pesado (tank) com armadura completa e escudo; foco em proteção e mitigação.  
- **Warrior:** combatente físico versátil; dano corpo a corpo e resistência moderada.  
- **Rogue (Male):** assassino ágil, furtividade, críticos, venenos; principal candidato a empunhadura dupla.  
- **Ranger:** atirador especializado; dano físico à distância com alta precisão.  
- **Pyromancer:** mago de fogo; dano mágico elevado, especialmente em área.  
- **Cryomancer:** mago de gelo; controle de campo e proteção, além de dano mágico.  
- **Druid:** usuário da natureza; cura, regeneração e buffs de suporte.  
- **Cleric:** sacerdote sagrado; cura concentrada, proteção e prevenção de morte.  
- **Berserker:** guerreiro em fúria; dano físico extremo com maior risco de sobrevivência.  
- **Shaman:** xamã espiritual; mistura de cura, buffs e dano mágico contextual (totens, espíritos, raios).

### 6.3. Classes planejadas para futuras versões

Lista de classes planejadas para expansões, sem especificação técnica nesta versão:

- Rogue (Female), Soldier, Monk, Sentinel, Battlemage, Darkmage, Necromancer, Alchemist, Dragon Slayer, Bard, Esper.

---

## 7. Status Negativos

### 7.1. Lista principal

- **Poison (Envenenado):** dano contínuo por turno.  
- **Bleed (Sangramento):** dano contínuo físico associado a cortes.  
- **Burn (Queimadura):** dano contínuo de fogo + redução de poder físico.  
- **Paralysis (Paralisado):** redução forte de AGI, chance de perder a ação.  
- **Sleep (Sono):** alvo não pode agir; duração curta.  
- **Freeze (Congelado):** alvo imobilizado; possível remoção por turno ou por efeitos específicos.  
- **Stun (Atordoado):** perda da próxima ação.  
- **Silence (Silenciado):** impede o uso de habilidades (skills).  
- **Confusion (Confuso):** chance de agir errado ou prejudicar-se.  
- **Root / Enraizado:** impede movimentação e reduz significativamente a Evasiva.

### 7.2. Debuffs numéricos e posicionais

- Redução de atributos (ATK/DEF/AGI/INT etc.).  
- Vulnerabilidades (dano recebido aumentado).  
- Aumento de custo de SP para determinadas ações.  
- Efeitos de deslocamento (empurrar, puxar, trocar posições).

---

## 8. Buffs (Status Positivos)

### 8.1. Atributos

- ATK Up, MATK Up, DEF Up, MDEF Up, AGI Up, Precision Up, Evasion Up, Critical Chance Up, All Stats Up.

### 8.2. Defesa e suporte

- Status Resist Up, Damage Reduction, Barrier/Shield, HP Regen, SP Regen, Elemental Resist Up, Elemental Damage Up, Healing Power Up.

### 8.3. Efeitos especiais

- Guard/Protect (redirecionar dano), HP Link (compartilhar dano), Damage Reflection/Thorns, Stealth/Invisibility, Cheat Death/Death Ward, Self-Revive/Phoenix, Transformation, SP Cost Down, Próximo Ataque Fortalecido/Crítico Garantido.

Todos os buffs interagem com os campos de Bonificação, Duração, Aplicação e Duração de Aplicação de Status Positivo.

---

## 9. Equipamentos e Proficências

### 9.1. Slots de equipamento

- Arma Principal  
- Mão Secundária (Escudo ou arma secundária)  
- Armor (corpo)  
- Leggins (pernas)  
- Item (equipamento físico/utilitário)  
- Magical Item (anel, amuleto, relíquia)

### 9.2. Armas de uma e duas mãos

- Campo “Equip” na FICHA:  
  - 1H – arma de uma mão,  
  - 2H – arma de duas mãos.

Regras:
- Arma 2H ocupa arma principal e mão secundária (sem escudo/arma secundária).  
- Arma 1H permite escudo ou arma secundária elegível.

### 9.3. Empunhadura dupla

- Arma 1H na mão principal + arma 1H elegível na mão secundária.
- Ataques da mão secundária:
  - dano reduzido e/ou menor precisão.
- Personagens sem escudo tornam-se menos protegidos.
- Maior afinidade: Rogue (Male) e Berserker.

### 9.4. Tipos de armadura por classe

- Knight – Plate  
- Warrior – Half Plate  
- Berserker – Half Plate  
- Rogue (Male) – Studded Leather  
- Ranger – Studded Leather  
- Druid – Studded Leather  
- Cleric – Padded  
- Shaman – Padded  
- Pyromancer – Leather  
- Cryomancer – Leather  

Cada classe só pode usar armaduras de seu tipo base.

### 9.5. Item e Magical Item

- **Item:** botas, capas, cintos, fragmentos especiais, itens físicos de calamidades.  
- **Magical Item:** anéis, amuletos, gemas e relíquias com efeitos mágicos.

---

## 10. Loot e Raridade

### 10.1. Filosofia

- Conteúdos simples → itens Básicos/Comuns, materiais básicos, pouco ouro.  
- Conteúdos intermediários → itens Incomuns/Raros, materiais melhores.  
- Conteúdos difíceis (dungeons avançadas, calamidades, raids) → principal fonte de itens Lendários/Míticos e materiais raros.

### 10.2. Tiers de raridade

Com base nas abas LVL1 (armas) e Armor (armaduras):

1. Básico  
2. Comum  
3. Incomum  
4. Raro  
5. Lendário  
6. Mítico  

Alguns rótulos internos (Raro+, Raro++) são usados apenas para organização; o jogador enxerga a raridade consolidada.

### 10.3. Influência de Gold/Item/Magical Find

- Gold Find → mais ouro.  
- Item Find → mais itens/materiais (mais rolagens de tabela).  
- Magical Item Find → maiores chances de raridades mais altas em conteúdos elegíveis.

---

## 11. Criação de Personagem e Backgrounds

### 11.1. Fluxo

1. Seleção de slot de personagem.  
2. Escolha entre Mono Classe ou Dual Classe.  
3. Seleção da(s) classe(s).  
4. Escolha de Background (história genérica baseada em perícias).  
5. Geração de aparência inicial conforme classe e tipo de armadura.  
6. Concessão de equipamento inicial base (modificado pelo Background).  
7. Início na estrada que leva ao vilarejo inicial.

### 11.2. Backgrounds

Backgrounds substituem raças/casas como decisão principal de “origem”:

Exemplos de backgrounds genéricos:
- Scholar (Erudito),
- Cultist (Cultista),
- Acolyte (Acólito),
- Soldier (Soldado),
- Guardian (Guardião),
- Outlander (Forasteiro),
- Scout (Batedor),
- Criminal (Criminoso),
- Artisan (Artífice/Comerciante),
- Performer (Artista).

Cada classe tem 3–4 backgrounds mais compatíveis, definidos pela soma de suas perícias principais (Acrobatics, Arcana, etc.) na FICHA RPG.  
Em Dual Classe, o jogador vê a **união** de backgrounds das duas classes.

Efeitos:
- Ajuste fino do kit inicial (itens, ouro, consumíveis, materiais).  
- Acesso antecipado ou favorecido a determinados grupos de **Common Passives**.

---

## 12. Common Passives e Slot de Passiva

### 12.1. Common Passives

- Listadas em aba própria, com:
  - Escala (indicador de profundidade/tier),
  - nome,
  - efeito,
  - afinidade com classes.
- Representam passivas globais que qualquer classe pode obter, respeitando afinidades.

### 12.2. Slot único de passiva ativa

- O personagem pode **aprender** várias passivas:
  - passivas de classe,
  - Common Passives,
  - passivas atreladas a itens (no futuro).
- Porém, só pode **equipar 1 passiva por vez** (Slot de Passiva Ativa).

Regras:
- Troca de passiva apenas fora de combate.  
- Todas as passivas competem pelo mesmo slot, inclusive as da classe.  
- Background e classe influenciam quais passivas são mais acessíveis/viáveis, mas não aumentam o número de slots.

---

## 13. História Inicial, Vilarejo e Quest da Rose

### 13.1. Chegada à vila

- Cena inicial: estrada ao sul da vila, com rio e ponte visíveis.
- Monólogo do personagem varia conforme o Background (motivo para chegar à vila).
- Um jovem guarda com seu cão aborda o personagem e pergunta quem ele é:
  - a resposta muda de acordo com o Background (Soldier, Scholar, Outlander, etc.),
  - em todos os casos, o jogador é encaminhado para falar com a líder da vila.

### 13.2. Vilarejo inicial

- 7 casas + praça central e arredores:
  - Casa do Lenhador e família (Rose desaparecida),
  - Casa de Rose (flores, artesanato, vazia até ser resgatada),
  - Casa de aventureiros desaparecidos (potencial futura moradia do jogador),
  - Casa do jovem guarda (recrutável em fases posteriores),
  - Casa da líder da vila (NPC central),
  - Casa da família da líder (introdução a mineração/forja),
  - Casa do mercador (loja principal; possui interesse em Rose).

- Arredores:
  - Norte: trilha para cachoeira, ponte e ruínas com goblins, lobos, etc.
  - Oeste: floresta mais densa (último local onde Rose foi vista), áreas de fazenda abandonadas e pântano com criaturas aquáticas/fantasmas.

### 13.3. Quest da Rose e Árvore Guardiã

- Rose, filha do lenhador, desaparece enquanto colhia flores.
- Ao investigar a floresta, o jogador:
  - enfrenta criaturas da floresta,
  - resolve um puzzle que abre passagem para uma região mágica com fadas e poltergeists.
- Fadas explicam que a **Árvore Guardiã** enlouqueceu:
  - chamaram Rose para tentar curá-la, devido ao seu conhecimento com cultivo de flores.
- O jogador ajuda Rose a preparar um remédio:
  - antes da cura surtir efeito, a árvore entra em estado de loucura e torna-se um mini-chefe.
- Após a batalha:
  - a árvore é derrotada,
  - as fadas lamentam, plantam uma nova semente,
  - Rose retorna à vila,
  - liberam-se novas quests (floricultura, artesanato, interação com fadas),
  - a praça da vila passa a funcionar como **ponto de teleporte/waystone** após quest específica.

---

## 14. Livro dos Contos e Lore

- O “Livro dos 100 Contos” é tratado como:
  - compilação de histórias antigas (ancestrais, eventos passados, mitos),
  - base para itens lendários/míticos, calamidades e chefes especiais.
- No jogo, pode se manifestar como:
  - coleção de entradas desbloqueáveis (semelhante a um “álbum” de lore),
  - recompensas ao derrotar chefes, concluir quests ou explorar regiões específicas.
- A versão textual do livro será reorganizada para:
  - melhorar clareza,
  - alinhar melhor cada conto a itens, regiões, raids e eventos do jogo.

---

Este documento consolidado em português apresenta, de forma técnica e estruturada, o conceito atual de **Adventures Unleashed: Rave Masters**, incluindo:

- visão geral,
- sistema de combate,
- atributos e status,
- classes e progressão,
- equipamentos, loot e raridade,
- criação de personagem e backgrounds,
- Common Passives e slot de passiva,
- narrativa inicial da vila e quest da Rose,
- e função do Livro dos Contos na construção de lore.

Detalhes numéricos e fórmulas específicas permanecem concentrados na **FICHA RPG** e em documentos complementares de balanceamento.
