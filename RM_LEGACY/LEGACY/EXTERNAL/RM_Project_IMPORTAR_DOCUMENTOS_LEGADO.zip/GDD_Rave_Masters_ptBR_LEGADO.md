
# Documento de Design de Jogo (GDD)  
## Adventures Unleashed: Rave Masters

---

## 1. Visão Geral

**Título:** Adventures Unleashed: Rave Masters  
**Gênero:** RPG tático em turnos, com forte ênfase em exploração, progressão de personagem e modos cooperativos e competitivos.

**Objetivo de experiência**

O jogo coloca o jogador no papel de um aventureiro que inicia sua trajetória em um vilarejo simples, cercado por floresta e ameaças de baixa escala. À medida que progride:

- descobre novas regiões, vilas e cidades;
- enfrenta criaturas e calamidades cada vez mais perigosas;
- desenvolve classes e combinações de classes;
- constrói configurações avançadas de habilidades e equipamentos;
- participa de conteúdos de fim de jogo, como incursões (raids) e arena competitivo.

Rave Masters é concebido como uma base para crescimento contínuo, com espaço claro para:

- novas classes,
- novos sistemas de progressão,
- expansão de mapa,
- eventos sazonais e metajogo competitivo.

---

## 2. Estrutura de Jogo e Progressão

### 2.1. Mundo

- Mundo segmentado em **regiões**, cada uma com:
  - vilarejos, cidades e acampamentos;
  - zonas selvagens e florestas;
  - dungeons, ruínas e áreas especiais;
  - calamidades e eventos próprios.
- O acesso a novas regiões é condicionado por:
  - avanço na narrativa principal;
  - conclusão de missões-chave;
  - superação de desafios de dificuldade crescente.

### 2.2. Ciclo de Progressão

**Início de jogo**
- O jogador chega a um vilarejo às margens de um rio.
- Aprende os fundamentos:
  - combate em turnos,
  - atributos e status,
  - uso de equipamentos,
  - sistema de teleporte local.
- É apresentado à primeira linha narrativa central:
  - desaparecimento de Rose,
  - estranhezas na floresta vizinha,
  - presença de fadas e da Árvore Guardiã.

**Meio de jogo**
- O jogador desbloqueia novas áreas, vilas e pontos de apoio.
- Começa a acessar:
  - dungeons de dificuldade intermediária,
  - calamidades regionais,
  - equipamentos de raridades mais altas (Incomum, Raro, Lendário).
- As configurações de personagem tornam-se mais complexas:
  - mais habilidades disponíveis,
  - passivas comuns,
  - especialização de classes.

**Conteúdo avançado**
- Foco em:
  - incursões (raids) contra grandes calamidades;
  - arena estruturada (confrontos em equipe com regras específicas);
  - eventos sazonais (festivais, feriados temáticos, eventos temporários).
- Enfrentamento de:
  - dragões elementais,
  - demônios e anjos corrompidos,
  - entidades vinculadas a fendas e distorções do mundo.

---

## 3. Sistema de Combate

### 3.1. Estrutura Básica

- Combate **em turnos**, por iniciativa.
- O jogador controla um **personagem principal**:
  - e pode contar com aliados, invocações, criaturas criadas ou controladas, conforme sua progressão.

### 3.2. Formações e Posições

Cada lado do combate utiliza uma formação de até **9 posições**, divididas em:

- **Linha frontal (3 posições)**
  - Recebe a maior parte do dano direto.
  - Favorece classes de combate corpo a corpo e funções de proteção.

- **Linha intermediária (3 posições)**
  - Função flexível:
    - suporte à frente e à retaguarda,
    - ataques à distância ou híbridos,
    - algumas formas de controle.

- **Linha de retaguarda (3 posições)**
  - Mais protegida e difícil de atingir.
  - Favorece conjuradores, arqueiros, suportes e funções de longo alcance.

Inimigos e unidades aliadas são posicionados nessas linhas, e muitas habilidades são afetadas pela posição (alcance, alvos válidos, precisão).

### 3.3. Ordem de Ação

- A ordem de ação é calculada principalmente a partir da **Agilidade (AGI)** de cada unidade.
- Existe um fator de variação controlada, para evitar sequências fixas repetitivas.
- Em geral:
  - maior AGI implica maior chance de agir antes,
  - efeitos de buff e debuff de AGI influenciam fortemente a iniciativa.

**Contextos:**
- Em conteúdos fora de rede (modo história, exploração):  
  - o turno não prossegue sem que o jogador escolha uma ação.
- Em conteúdos online (como arena e incursões cooperativas):  
  - há um tempo máximo para decisão por turno;
  - ao término do tempo, a ação pode ser escolhida automaticamente ou o turno pode ser perdido, conforme regra do modo.

### 3.4. Movimento e Troca de Posição

- A posição básica do personagem, ao iniciar o combate, tende a permanecer fixa.
- Determinadas habilidades permitem:
  - avançar ou recuar entre linhas,
  - trocar de posição com um aliado,
  - aproximar-se de um inimigo específico,
  - expulsar ou puxar inimigos de suas posições.

Esses mecanismos fazem com que posicionamento inicial, leitura de formação inimiga e uso de mobilidade sejam componentes importantes da estratégia.

### 3.5. Derrota e Consequências

- No conteúdo padrão, o jogo procura evitar punição excessiva por derrotas:
  - há boa disponibilidade de itens de cura,
  - o foco é aprendizado e progressão.
- Consequências usuais de uma derrota:
  - consumo de recursos (itens, SP),
  - perda de tempo de jogo,
  - necessidade de ajustar configuração de habilidades e equipamentos.

Em conteúdos avançados, podem existir:

- limitações de ressurgimento,
- redução ou perda de recompensas em caso de falha,
- condições estritas para conclusão de encontros (por exemplo, sem mortes).

### 3.6. Espaços de Habilidades

Cada personagem dispõe dos seguintes **espaços de habilidades**:

- **Habilidade de Suporte** – obrigatoriamente uma habilidade de suporte.  
- **Habilidade A** – habilidade ativa, de reação ou suporte.  
- **Habilidade B** – habilidade ativa, de reação ou suporte.  
- **Habilidade C** – habilidade ativa, de reação ou suporte.  
- **Habilidade S (especial)** – habilidade ativa, de reação ou suporte.  
- **Habilidade Suprema** – habilidade de maior impacto do personagem.

Regras de progressão:

- Os espaços de habilidades (Suporte, A, B, C e S) possuem **nível próprio** (1 a 3).
- O nível do espaço determina a versão da habilidade equipada naquele espaço.
- O espaço **S** é considerado nível máximo desde a liberação.
- O espaço S é desbloqueado em um marco específico de nível do personagem (sugerido: nível 80).
- Habilidades podem ser rearranjadas entre espaços **fora de combate**.

### 3.7. Habilidades Supremas

- Cada classe possui uma lista de **habilidades supremas**.
- O personagem pode aprender múltiplas habilidades supremas ao longo da progressão.
- Apenas **uma** habilidade suprema pode ser equipada por vez.

Características:

- custo elevado de SP;
- tempo de recarga relevante;
- efeito de grande impacto (dano em área, controle, suporte extremo, mudanças de estado).

---

## 4. Atributos e Status

### 4.1. Atributos Principais

O jogo utiliza **seis atributos principais**, usados para:

- determinar HP, SP e valores base de dano;
- definir defesas física e mágica;
- influenciar precisão, evasão, chance de crítico;
- alimentar os status derivados.

Os nomes e fórmulas detalhadas são definidos em uma tabela técnica de atributos e balanceamento.

### 4.2. Status Derivados

Entre os principais status derivados estão:

- **Poder Físico**, **Poder Mágico**  
- **Defesa Física**, **Defesa Mágica**  
- **Precisão Física**, **Precisão Mágica**  
- **Evasiva (EVA)**  
- **Crítico Físico**, **Crítico Mágico**  
- **Resistência a Status Negativos**  
- Parâmetros de:
  - duração de status negativos sofridos,
  - eficácia de aplicação de status negativos,
  - duração de status positivos recebidos,
  - chance de aplicação de status positivos.

### 4.3. Status de Sorte

Três status especiais relacionam-se a recompensas:

- **Gold Find** – aumenta a quantidade de ouro recebida.  
- **Item Find** – aumenta a quantidade de itens e materiais recebidos.  
- **Magical Item Find** – aumenta a chance de itens de raridade mais alta em conteúdos onde tais raridades são possíveis.

---

## 5. Níveis e Profissões

### 5.1. Nível de Personagem

Há duas configurações principais:

- **Personagem de Classe Única (Mono Classe)**
  - Nível máximo: 100.
  - Toda a experiência de combate é investida em uma única classe.

- **Personagem de Dupla Classe (Dual Classe)**
  - Nível máximo: 180.
  - As habilidades e passivas de duas classes são desenvolvidas ao longo de uma progressão mais longa.

A opção entre Mono Classe e Dual Classe é escolhida na criação de personagem e **não pode ser alterada**.

### 5.2. Profissões (Soft Skills)

Além do nível de combate, o personagem possui níveis de **profissões**, por exemplo:

- Mineração,  
- Corte de madeira,  
- Culinária,  
- e outras a definir.

Características:

- cada profissão possui nível próprio, até o máximo de 100;
- níveis mais altos permitem:
  - coletar materiais mais raros,
  - acessar receitas avançadas de criação,
  - destravar interações especiais no mundo.

---

## 6. Classes Jogáveis

### 6.1. Lista de Classes Iniciais

As seguintes classes estarão disponíveis na versão inicial:

1. Knight  
2. Warrior  
3. Rogue (Male)  
4. Ranger  
5. Pyromancer  
6. Cryomancer  
7. Druid  
8. Cleric  
9. Berserker  
10. Shaman  

Podem ser escolhidas como classe única ou combinadas em dupla classe.

### 6.2. Perfis de Classe

- **Knight** – defensor de armadura pesada e escudo; foca em absorver dano, proteger aliados e reduzir o risco para o grupo.  
- **Warrior** – combatente físico versátil; combina dano corpo a corpo com resistência moderada.  
- **Rogue (Male)** – assassino ágil, furtivo, com foco em dano crítico, venenos e empunhadura dupla de armas leves.  
- **Ranger** – atirador à distância; especialista em arco/besta, com alta precisão e capacidade de focar alvos prioritários.  
- **Pyromancer** – mago de fogo; produz grande quantidade de dano mágico, com ênfase em queimaduras e efeitos em área.  
- **Cryomancer** – mago de gelo; controle de campo, redução de mobilidade inimiga e proteção através de barreiras.  
- **Druid** – manipulador de forças da natureza; cura, regeneração, buffs e controle leve do ambiente.  
- **Cleric** – sacerdote sagrado; cura concentrada, proteção espiritual e prevenção/reversão de morte em situações críticas.  
- **Berserker** – guerreiro em fúria; dano físico extremo com baixa preocupação defensiva, operando próximo do limite de sobrevivência.  
- **Shaman** – xamã espiritual; suporte híbrido, usando totems, espíritos e relâmpagos para combinar cura, buffs e dano mágico.

### 6.3. Classes Futuras

Há planejamento de classes adicionais para expansões (por exemplo, variação feminina de Rogue, classes militares, necromânticas e híbridas), que não são detalhadas neste documento.

---

## 7. Status Negativos

### 7.1. Conjunto Principal

O sistema de status negativos é intencionalmente compacto e legível:

- **Poison (Envenenado)** – dano contínuo por turno.  
- **Bleed (Sangramento)** – dano contínuo associado a cortes e perfurações.  
- **Burn (Queimadura)** – dano contínuo de fogo e redução de poder físico.  
- **Paralysis (Paralisado)** – grande redução de AGI, com chance de perder a ação.  
- **Sleep (Sono)** – impede ação enquanto durar; duração curta.  
- **Freeze (Congelado)** – alvo não age; chance de remoção a cada turno ou por condições específicas.  
- **Stun (Atordoado)** – perda da próxima ação.  
- **Silence (Silenciado)** – impede o uso de habilidades; permite ataques básicos e itens.  
- **Confusion (Confuso)** – pode fazer o alvo agir de forma incorreta, desperdiçando a ação ou atingindo a si mesmo.  
- **Root / Enraizado** – impede movimentos e reduz fortemente a evasiva.

### 7.2. Debuffs Numéricos e de Posição

Além dos status acima, habilidades podem aplicar:

- reduções diretas de atributos (ATK, DEF, AGI, INT etc.);
- efeitos de vulnerabilidade (aumento de dano recebido);
- aumentos de custo de SP;
- deslocamentos de posição (empurrar, puxar, trocar).

---

## 8. Status Positivos

### 8.1. Buffs de Atributos

Principais:

- aumento de Poder Físico,
- aumento de Poder Mágico/INT,
- aumento de Defesas,
- aumento de AGI,
- aumento de Precisão,
- aumento de Evasiva,
- aumento de chance de crítico,
- aumento moderado de diversos atributos simultaneamente.

### 8.2. Buffs Defensivos e de Suporte

- aumento de resistência a status negativos;  
- redução percentual de dano recebido;  
- escudos temporários de HP;  
- regeneração de HP por turno;  
- regeneração de SP por turno;  
- aumento de resistência elemental;  
- aumento de dano elemental;  
- aumento de poder de cura.

### 8.3. Buffs Especiais

Exemplos:

- redirecionar dano de aliados para o usuário (proteção);  
- compartilhar dano entre aliados (vínculo de HP);  
- refletir parte do dano recebido;  
- entrar em estado furtivo ou invisível, com bonificações no próximo ataque;  
- impedir a morte uma vez, mantendo o personagem com 1 HP;  
- ressuscitar automaticamente após a morte, com parte do HP;  
- entrar em forma ou estado transformado, alterando múltiplos atributos e, em alguns casos, habilidades disponíveis;  
- reduzir custo de SP de determinadas habilidades;  
- fortalecer o próximo ataque ou garantir crítico.

---

## 9. Equipamentos e Proficências

### 9.1. Espaços de Equipamento

Cada personagem possui:

- Arma Principal  
- Mão Secundária (escudo ou arma secundária)  
- Armadura (corpo)  
- Leggins (pernas)  
- Item físico/utilitário  
- Item mágico

### 9.2. Armas de Uma Mão e Duas Mãos

- Armas são classificadas como:
  - de uma mão,
  - de duas mãos.

Regras:

- Arma de duas mãos ocupa arma principal e mão secundária, impedindo uso de escudo ou arma secundária.  
- Arma de uma mão permite uso de:
  - escudo, ou
  - arma secundária elegível (empunhadura dupla).

Algumas armas de uma mão são marcadas como adequadas à mão secundária, permitindo combinações ofensivas com duas armas.

### 9.3. Empunhadura Dupla

- Configuração com uma arma de uma mão na mão principal e outra na mão secundária.
- Ataques da arma secundária sofrem:
  - penalidade de dano e/ou
  - penalidade de precisão.
- A ausência de escudo reduz a proteção física e mágica do personagem.
- As classes com maior afinidade temática com empunhadura dupla são:
  - Rogue (Male),
  - Berserker.

### 9.4. Armaduras por Classe

Cada classe utiliza um tipo de armadura base:

- Knight – armaduras de placas pesadas.  
- Warrior – armaduras parcialmente em placas.  
- Berserker – armaduras parcialmente em placas.  
- Rogue (Male) – couro reforçado (studded leather).  
- Ranger – couro reforçado.  
- Druid – couro reforçado.  
- Cleric – armaduras acolchoadas.  
- Shaman – armaduras acolchoadas.  
- Pyromancer – couro leve.  
- Cryomancer – couro leve.  

O personagem só pode equipar armaduras compatíveis com o tipo definido pela classe.

### 9.5. Itens Físicos e Itens Mágicos

- **Item físico:**  
  - botas, capas, cintos, fragmentos de armadura, peças especiais obtidas em calamidades ou missões.
- **Item mágico:**  
  - anéis, amuletos, gemas e relíquias,
  - normalmente associados a efeitos mágicos específicos (bônus de atributos, resistência, ativação de efeitos).

---

## 10. Sistema de Itens e Raridade

### 10.1. Filosofia

- Conteúdos simples:
  - fornecem itens básicos/comuns, materiais simples e pouco ouro.
- Conteúdos intermediários:
  - fornecem itens incomuns/raros, materiais de qualidade superior.
- Conteúdos difíceis (dungeons avançadas, calamidades, incursões e chefes centrais):
  - principal fonte de itens lendários e míticos,
  - principal fonte de materiais raros usados em sistemas avançados de criação e melhoria.

### 10.2. Níveis de Raridade

Seis níveis principais:

1. Básico  
2. Comum  
3. Incomum  
4. Raro  
5. Lendário  
6. Mítico  

- Itens básicos e comuns compõem o equipamento inicial e de baixa dificuldade.  
- Itens incomuns e raros são associados a encontros e missões intermediárias.  
- Itens lendários são ligados a chefes, marcos narrativos e desafios de alto nível.  
- Itens míticos representam o teto de poder da versão inicial, com raridade muito alta.

Rotulações internas adicionais podem existir para fins de balanceamento, mas o jogador vê apenas a raridade consolidada.

### 10.3. Influência dos Status de Sorte

- **Gold Find:** aumenta o ouro ganho em combate, baús e missões.  
- **Item Find:** aumenta o número de itens e materiais recebidos.  
- **Magical Item Find:** aumenta a chance de que itens recebidos sejam de raridade mais alta, em conteúdos que já tenham essa possibilidade.

---

## 11. Criação de Personagem

### 11.1. Fluxo

1. Seleção de slot de personagem.  
2. Escolha entre classe única ou dupla classe.  
3. Escolha de classe(s) jogáveis.  
4. Seleção de **Antecedente** (história de origem).  
5. Geração de aparência inicial baseada na classe e tipo de armadura.  
6. Entrega de equipamento inicial básico ajustado conforme o Antecedente.  
7. Início do jogo na estrada que leva ao vilarejo inicial.

### 11.2. Antecedentes

Os Antecedentes substituem sistemas de raça/linhagem como escolha principal de origem do personagem.

Exemplos de Antecedentes:

- Erudito (Scholar) – foco em estudo, conhecimento e magia.  
- Cultista (Cultist) – vinculado a cultos, rituais e segredos proibidos.  
- Acólito (Acolyte) – ligado a templos, fé e serviços religiosos.  
- Soldado (Soldier) – experiência em exército ou milícia organizada.  
- Guardião (Guardian) – atuação como guarda de cidade ou protetor de caravanas.  
- Forasteiro (Outlander) – vida em regiões selvagens e afastadas.  
- Batedor (Scout) – reconhecimento, infiltração e rastreamento.  
- Criminoso (Criminal) – histórico de atividades ilícitas e contrabando.  
- Artífice/Comerciante (Artisan) – ofício, comércio e investigação prática.  
- Artista (Performer) – atuação em entretenimento e manipulação social.

Cada classe possui alguns Antecedentes mais coerentes com seus valores de perícias; personagens de dupla classe acessam a união das opções de ambas as classes.

Efeitos gerais dos Antecedentes:

- pequenas variações na distribuição de:
  - ouro inicial,
  - consumíveis,
  - materiais iniciais,
  - equipamento básico;
- acesso facilitado a determinados grupos de Passivas Comuns.

---

## 12. Passivas Comuns

### 12.1. Conceito

Passivas Comuns são habilidades passivas:

- não exclusivas de uma classe específica;
- organizadas por um indicador de escala (profundidade ou tier);
- com afinidade maior com determinados grupos de classes.

Exemplos de efeitos:

- aumento de evasão no primeiro ataque recebido;  
- aumento de experiência ganha em combates difíceis;  
- redução de efeitos de medo ou confusão;  
- bônus de movimento em terreno natural;  
- regeneração leve de SP fora de combate;  
- aumento de chance de crítico contra inimigos debilitados;  
- resistência a elementos;  
- aumento de letalidade em lutas prolongadas.

### 12.2. Espaço Único de Passiva

- O personagem pode aprender várias passivas (de classe e comuns).  
- No entanto, só pode **manter uma passiva ativa por vez**:
  - um espaço único de Passiva Ativa.
- Todas as passivas competem por esse espaço, inclusive as originadas da classe principal.
- A troca de passiva ativa ocorre apenas fora de combate.

---

## 13. Introdução Narrativa: Vilarejo e Rose

### 13.1. Chegada à Vila

- Cena inicial:
  - estrada de terra ao sul de um vilarejo,
  - rio ao lado,
  - ponte e placas indicando a entrada da comunidade.
- Um texto breve apresenta o tom:
  - relatos de criaturas estranhas,
  - rumores de desaparecimentos,
  - menção a problemas na floresta.

Dependendo do Antecedente escolhido:

- o monólogo interno do personagem antes de entrar na vila muda (motivação pessoal para chegar ali);
- a resposta ao jovem guarda que aborda o personagem na entrada também varia.

Em todos os casos:

- o guarda encaminha o personagem à líder do vilarejo.

### 13.2. Estrutura do Vilarejo

O vilarejo possui:

- **Casa do Lenhador e família:**  
  - lenhador, esposa, filho mais novo;  
  - Rose, filha mais velha, desaparecida.

- **Casa de Rose:**  
  - cercada de flores;  
  - vazia até a conclusão da quest de resgate;  
  - depois, passa a ser ponto para quests de floricultura e artesanato.

- **Casa dos antigos aventureiros:**  
  - atualmente vazia;  
  - próxima ao rio, com três lápides;  
  - pode futuramente se tornar moradia do jogador.

- **Casa do jovem guarda e seu cão:**  
  - guarda inexperiente, herdeiro de um pai desaparecido em missão;  
  - personagem recrutável em estágios posteriores.

- **Casa da líder do vilarejo:**  
  - figura idosa e sábia;  
  - principal fonte de orientação narrativa e missões iniciais.

- **Casa da família da líder:**  
  - filho, nora e duas crianças;  
  - introduzem mineração, minérios e forja.

- **Casa do mercador:**  
  - comerciante de personalidade forte, estoque variado;  
  - aprecia aventureiros e mantém interesse especial no retorno de Rose.

Arredores imediatos:

- trilha ao norte para cachoeira, ponte e ruínas com pequenos monstros;  
- floresta densa a oeste, última área onde Rose foi vista;  
- áreas de fazendas abandonadas e pântano com criaturas aquáticas e fantasmas.

### 13.3. Quest da Rose e Árvore Guardiã

- Rose desapareceu enquanto coletava flores na floresta.  
- Ao investigar, o personagem:
  - enfrenta criaturas da floresta;
  - resolve um quebra-cabeça ambiental para acessar uma área mágica;
  - encontra fadas e manifestações espirituais.

As fadas explicam que:

- a Árvore Guardiã enlouqueceu;  
- elas chamaram Rose para tentar curá-la, devido ao seu conhecimento de cultivo.

O personagem auxilia na preparação de um remédio, mas:

- antes do efeito positivo, a árvore entra em surto de loucura e se torna um mini-chefe.  
- após a batalha:
  - a Árvore Guardiã é derrotada;
  - uma nova semente é plantada;
  - Rose retorna ao vilarejo.

Consequências:

- novas missões relacionadas a flores, artesanato e fadas são liberadas;  
- o jogador fortalece laços com NPCs da vila;  
- a praça do vilarejo passa a funcionar como ponto de teleporte, após conclusão de uma missão específica.

---

## 14. Livro dos Contos e Expansão de Mundo

- O **Livro dos Contos** (conjunto de histórias de gerações anteriores) serve como base de lore do mundo.
- Muitos itens lendários e míticos, calamidades e chefes têm origem ou referência nesses contos.
- No jogo, o Livro dos Contos pode ser apresentado como:
  - coleção de entradas desbloqueáveis,
  - associadas a chefes derrotados, eventos resolvidos e áreas exploradas.
- O conteúdo das histórias será estruturado de modo a:
  - reforçar a identidade de cada região e calamidade;
  - dar contexto a itens raros;
  - preparar o terreno para expansões futuras de mapa e sistemas.

---

Este documento descreve a visão de design do jogo **Adventures Unleashed: Rave Masters**, cobrindo:

- estrutura de mundo e progressão,
- sistema de combate,
- atributos e status,
- níveis e profissões,
- classes jogáveis,
- status negativos e positivos,
- equipamentos e raridade de itens,
- criação de personagem e antecedentes,
- passivas comuns,
- introdução narrativa no vilarejo inicial,
- papel do Livro dos Contos na expansão de lore.

A partir deste material, podem ser elaborados documentos específicos de balanceamento, narrativa detalhada, interface de usuário e implementação técnica.
