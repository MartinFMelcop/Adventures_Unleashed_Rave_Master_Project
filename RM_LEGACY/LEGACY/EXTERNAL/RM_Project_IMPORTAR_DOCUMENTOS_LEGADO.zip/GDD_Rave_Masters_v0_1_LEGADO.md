
# GDD – Adventures Unleashed: Rave Masters (Versão 0.1)

## 1. Visão Geral

**Título provisório:** Adventures Unleashed: Rave Masters  
**Gênero:** RPG tático com foco em exploração, progressão profunda de personagem e metagame de PvE/PvP.  
**Referências principais:**
- **Runescape / GW2 / Minecraft:** exploração, coleta, sobrevivência leve, sensação de mundo vivo.
- **Pokémon (cartucho + VGC):** combate em turnos com muita importância de status, buffs/debuffs, leitura de turno e sinergia de equipe.
- **MMOs em geral:** endgame com raids, eventos sazonais (Natal, Páscoa, Halloween, etc.), arena PvP estruturada.

**Visão de experiência:**
- O jogador começa em um vilarejo simples, lutando contra criaturas fracas de floresta.
- Ao longo da jornada, desbloqueia novas vilas, cidades e acampamentos, enfrentando desafios cada vez mais complexos.
- No late game, luta contra dragões, anjos, demônios e entidades elementais absurdamente poderosas, em raids e PvP competitivo.
- O jogo é pensado como uma base que crescerá com o tempo (novas classes, regiões, sistemas).

---

## 2. Estrutura de Jogo e Progressão

### 2.1. Estrutura de mundo

- Mundo grande, dividido em **regiões**, vilas, cidades e zonas selvagens.
- O jogador **desbloqueia vilas/cidades/acampamentos** conforme avança na exploração e na campanha.
- Cada região traz:
  - novos tipos de criaturas,
  - novos materiais e recursos,
  - novos NPCs, quests, dungeons, calamidades e possibilidades de loot.

### 2.2. Loop de progressão

**Early Game**
- Começa no **primeiro vilarejo**.
- Faz quests básicas:
  - ajuda moradores,
  - aprende sistemas (combate, equipamentos, teleporte/praça, etc.),
  - resolve a primeira grande trama: desaparecimento de Rose e a árvore guardiã.
- Luta contra criaturas fracas: insetos, pequenos lobos, goblins básicos, fantasmas fracos, etc.

**Mid Game**
- Exploração de regiões mais amplas.
- Desbloqueio de novas vilas/cidades/acampamentos (checkpoints de progressão).
- Maior variedade de builds:
  - mais habilidades de classe,
  - mais Common Passives disponíveis,
  - melhores equipamentos (Raros, Lendários).
- Começam a aparecer calamidades de médio porte e dungeons desafiadoras.

**Late Game**
- Foco em:
  - **raids** contra grandes calamidades,
  - **arena PvP** com formato competitivo (4v4, bans/picks),
  - eventos sazonais (Natal, Páscoa, Halloween, etc.).
- Enfrenta inimigos extremamente poderosos:
  - dragões elementais,
  - demônios,
  - anjos corrompidos,
  - entidades cósmicas.
- Meta de builds muito rico: ultimates, status, equipamentos míticos, sinergias entre classes.

---

## 3. Sistema de Combate

### 3.1. Estrutura do combate

- Combate **em turnos**, com forte peso em:
  - AGI (ordem de turno),
  - precisão/evasão,
  - buffs/debuffs e controle.
- **Party do jogador:**
  - No conceito base, o jogador controla **um personagem principal**.
  - Ao longo da progressão, pode:
    - contratar aliados,
    - invocar pets,
    - criar elementais,
    - levantar mortos-vivos,
  - até ter **até 9 aliados em campo** (slots de “party estendida”).
- **Inimigos:**
  - Até **9 inimigos simultâneos**, organizados em linhas.
- **Grid de combate:**
  - 3 posições na **frente** – recebem mais foco, melee dominante.
  - 3 posições no **meio** – papel flexível; protegem retaguarda, atacam à distância ou dão suporte.
  - 3 posições na **retaguarda** – mais difíceis de acertar, focados em ataques à distância e suporte.

### 3.2. Ordem de turnos

- Ordem de ação baseada em **AGI / Speed**.
- Existe um fator de “sorte / speed draw”:
  - personagens com AGI alta normalmente agem primeiro,
  - mas há variação aleatória leve para evitar extremos determinísticos.
- **Exploração offline:**
  - o turno **não avança** enquanto o jogador não escolhe ação.
- **Modos online (PvP, raids):**
  - existe um **tempo limite** de ação por turno (inspirado em Pokémon VGC).
  - Se o tempo acabar, o turno pode:
    - escolher uma ação padrão,
    - ou resultar em “não agir” (a definir).

### 3.3. Posição e movimento

- Em condições normais, o personagem **não troca de posição** durante o combate.
- Certas habilidades permitem:
  - dash para frente,
  - recuo,
  - troca de posição com aliado ou inimigo,
  - sumir e reaparecer ao lado do alvo (Rogue, habilidades específicas de Soldier/Warrior, etc.).

### 3.4. Morte e punição

- Em geral, espera-se que o jogador:
  - **não morra com frequência**, principalmente em early/mid game,
  - tenha acesso a **muitos itens de cura**.
- Punição é mais focada em:
  - perda de recursos (consumíveis, SP, tempo),
  - debuffs temporários (status negativos que permanecem por um tempo fora da batalha),
  - necessidade de reorganizar estratégias.
- Em conteúdos difíceis (raids, calamidades, PvP), punitividade é maior:
  - mortes podem limitar recompensas ou exigir condições específicas.

### 3.5. Habilidades e slots

O personagem tem os seguintes **slots de habilidades**:

- **Habilidade Suporte** – obrigatoriamente uma skill de suporte.
- **Habilidade A** – ativa/reação ou suporte.
- **Habilidade B** – ativa/reação ou suporte.
- **Habilidade C** – ativa/reação ou suporte.
- **Habilidade S** – slot especial, ativa/reação ou suporte.
- **Habilidade Ultimate** – Ultimate equipada do personagem.

Regras:
- Slots **Suporte, A, B, C, S** têm **níveis de 1 a 3**:
  - ex.: “Bola de Fogo Nível 1/2/3”, dependendo do nível do slot.
- O slot **S** já nasce como **nível 3** desde o início.
- Com o avanço de nível, os slots A, B e C vão ficando mais fortes (liberando nível 2 e 3).
- Em certo nível (proposta: **nível 80**), o jogador libera o slot **S**.
- O jogador pode:
  - trocar as habilidades equipadas nesses slots **fora de combate**,
  - testar diferentes builds.

### 3.6. Ultimates

- Cada classe tem uma **lista própria de Ultimates**.
- O personagem pode:
  - **aprender várias Ultimates**,
  - mas **equipar apenas uma** no slot de Ultimate.
- Ultimates:
  - têm **custo alto de SP**,  
  - possuem **Cooldown**,  
  - geram impacto grande na batalha (controle de campo, dano massivo, suporte pesado, etc.).
- No late game, espera-se que:
  - combates sejam uma “sopa” de interações de skills, buffs, debuffs e Ultimates,
  - com builds altamente personalizadas.

---

## 4. Atributos e Derivados

### 4.1. Atributos base

- O jogo trabalha com **6 atributos básicos** (detalhados na FICHA RPG).
- Esses atributos influenciam diretamente:
  - HP, SP,
  - dano físico e mágico,
  - defesa física e mágica,
  - precisão e evasão,
  - etc.

(Os nomes exatos e fórmulas estão na FICHA e podem ser referenciados diretamente no design técnico.)

### 4.2. Status derivados

A partir dos 6 atributos base, são derivados status como:

- **Evasiva (EVA)**  
- **Poder Físico**  
- **Poder Mágico**  
- **Defesa Física**  
- **Defesa Mágica**  
- **Crítico Físico**  
- **Crítico Mágico**  
- **Precisão Física**  
- **Precisão Mágica**  
- **Resistência a Status Negativo**  
- **Duração de Status Negativo (recebido)**  
- **Eficácia de Status Negativo (aplicado)**  
- **Duração da Aplicação de Status Negativo (aplicado)**  
- **Bonificação de Status Positivo**  
- **Duração da Bonificação de Status Positivo**  
- **Aplicação de Status Positivo**  
- **Duração de Aplicação de Status Positivo**

### 4.3. Status de sorte

Existem **três status especiais** ligados a loot:

- **Gold Find**  
  - Aumenta a quantidade de ouro ganho.
- **Item Find**  
  - Aumenta a quantidade de itens/materiais dropados.
- **Magical Item Find**  
  - Aumenta a chance de itens de maior raridade (Raro, Lendário, Mítico).

---

## 5. Sistema de Level

### 5.1. Nível de personagem

- **Mono Classe:**
  - Nível máximo do personagem: **100**.
  - Toda experiência investida numa única classe.

- **Dual Classe:**
  - Nível máximo do personagem: **180**.
  - Progressão mais longa e complexa, combinando duas árvores de classe.

### 5.2. Níveis de Soft Skills (Profissões)

- Além do nível de combate, o personagem possui **Soft Skills** (profissões), inspiradas em Runescape:
  - Mineração,
  - Lenhador,
  - Culinária,
  - entre outras (a definir e/ou agrupar por profissão).
- Cada Soft Skill:
  - tem nível próprio, **indo até 100**,  
  - desbloqueia acesso a:
    - materiais melhores,
    - receitas de craft,
    - interações especiais com o mundo.

---

## 6. Classes

### 6.1. Classes iniciais (v1)

A versão inicial terá **10 classes jogáveis**:

1. **Knight**  
2. **Warrior**  
3. **Rogue (Male)**  
4. **Ranger**  
5. **Pyromancer**  
6. **Cryomancer**  
7. **Druid**  
8. **Cleric**  
9. **Berserker**  
10. **Shaman**

Todas podem ser escolhidas como **mono** ou em **combinações de dual class**.

### 6.2. Resumo por classe (fantasia e papel)

**Knight**
- Tank icônico de armadura pesada e escudo.
- Papel: **tank defensivo**, proteção de aliados, redução de dano, possível reflexão.

**Warrior**
- Lutador físico direto, pancadaria honesta.
- Papel: **melee DPS / bruiser**, mistura de dano e alguma resistência.

**Rogue (Male)**
- Assassino ágil, furtivo, crítico e veneno.
- Papel: **DPS físico de alta AGI** com foco em explosão de dano em alvo único.
- Classe principal de **dual wield** (duas armas leves).

**Ranger**
- Arqueiro/atirador, especialista em dano à distância.
- Papel: **ranged DPS físico** com alta precisão e crítico, controle de alvos frágeis.

**Pyromancer**
- Mago do fogo, explosões e dano em área.
- Papel: **mage de dano bruto**, single-target e AoE, focado em Burn.

**Cryomancer**
- Mago do gelo, controle de campo e congelamento.
- Papel: **controle + dano mágico**, focado em slow, freeze e proteção.

**Druid**
- Guardião da natureza, cura e controle leve de campo.
- Papel: **healer/suporte de HoT e buffs suaves**, sinérgico com lore da floresta.

**Cleric**
- Sacerdote sagrado, cura e proteção divina.
- Papel: **healer de burst e suporte defensivo**, escudos e anti-morte.

**Berserker**
- Guerreiro enlouquecido, fúria extrema.
- Papel: **melee DPS extremo**, alto risco/alta recompensa, sinergia com pouca vida.

**Shaman**
- Xamã espiritual, totems, relâmpagos e cura ritualística.
- Papel: **suporte híbrido (cura + dano)**, com foco em totems e buffs em grupo.

### 6.3. Classes planejadas para futuras versões

(sem detalhes mecânicos, apenas intenção)

- **Rogue (Female)** – variação de Rogue com foco em venenos e debuffs.  
- **Soldier** – frontliner militar, simples e disciplinado.  
- **Monk** – artista marcial, combos físicos, foco em desarmado/armas leves.  
- **Sentinel** – tank mais “tartaruga”, proteções reativas.  
- **Battlemage** – híbrido corpo a corpo + magia.  
- **Darkmage** – mago de maldições e dano sombrio.  
- **Necromancer** – usuário de magia da morte, summons e drenagem.  
- **Alchemist** – bombas, poções e itens consumíveis.  
- **Dragon Slayer** – especialista em abater dragões e monstros gigantes.  
- **Bard** – suporte musical, buffs/debuffs baseados em canções.  
- **Esper** – caster psíquico, controle mental e de status.

---

## 7. Status Negativos (Debuffs)

### 7.1. Filosofia

- Inspirado em Pokémon:
  - efeitos simples e claros,
  - duração curta ou média,
  - impacto forte, sem excesso de tipos.
- Interagem com:
  - Resistência a Status Negativo,
  - Duração de Status Negativo,
  - Eficácia de Status Negativo,
  - Duração da Aplicação de Status Negativo.

### 7.2. Lista de Status Negativos (v1)

1. **Poison (Envenenado)**
   - Dano contínuo de HP ao final de cada turno (DoT).
   - Típico de venenos, monstros, Rogue, Alchemist (futuro).
2. **Bleed (Sangramento)**
   - DoT físico baseado em cortes/perfurações.
   - Dano contínuo, geralmente mais forte que Poison, porém mais curta duração.
3. **Burn (Queimadura)**
   - DoT de fogo + redução de Poder Físico.
   - Vindo de Pyromancer, ataques de fogo, armadilhas etc.
4. **Paralysis (Paralisado)**
   - Redução forte de AGI.
   - Cada turno, chance de não agir.
5. **Sleep (Sono)**
   - Alvo não pode agir enquanto dorme.
   - Duração curta, especialmente em PvP.
6. **Freeze (Congelado)**
   - Imobilização quase total; alvo não age enquanto congelado.
   - Chance de “descongelar” a cada turno, mais raro e curto que Sleep.
7. **Stun (Atordoado)**
   - Perde a próxima ação (1 turno).
8. **Silence (Silenciado)**
   - Não pode usar habilidades (só ataques básicos/itens).
9. **Confusion (Confuso)**
   - Cada turno, chance de agir normalmente ou errar/atingir a si mesmo.
10. **Root / Enraizado**
    - Não pode executar ações de movimentação,
    - EVA bastante reduzida (mais fácil de acertar).

### 7.3. Debuffs de atributo e efeitos especiais

Além dos status principais, existem:

- Debuffs de atributo:
  - ATK Down, DEF Down, STR/AGI/DEX/INT Down, etc.
- Debuffs de vulnerabilidade:
  - Dano recebido +X%, “Marca da Morte”, “Ponto Fraco”.
- Debuffs de custo:
  - Custo de SP aumentado.
- Efeitos posicionais:
  - Empurrão/knockback, puxar, trocar de lugar.

Esses são tratados como **modificadores numéricos** e combinam com o sistema de buffs/debuffs de atributo.

---

## 8. Status Positivos (Buffs)

### 8.1. Buffs de atributos principais

- **ATK Up (Poder Físico ↑)**  
- **MATK Up (Poder Mágico/INT ↑)**  
- **DEF Up (Defesa Física ↑)**  
- **MDEF Up (Defesa Mágica ↑)**  
- **AGI/Speed Up (Velocidade ↑)**  
- **Accuracy Up (Precisão ↑)**  
- **EVA Up (Evasiva ↑)**  
- **Crit Chance Up (Chance de Crítico ↑)**  
- **All Stats Up (Todos Atributos ↑)**

### 8.2. Buffs defensivos e de suporte

- **Status Resist Up** – mais resistência a debuffs.  
- **Damage Reduction** – redução percentual de dano.  
- **Barrier/Shield** – HP temporário que absorve dano.  
- **HP Regen (HoT)** – cura por turno.  
- **SP Regen** – recuperação de SP por turno.  
- **Elemental Resist Up** – resistência a fogo/gelo/raio/natureza etc.  
- **Elemental Damage Up** – aumento de dano de um elemento.  
- **Healing Power Up** – aumento da cura gerada.

### 8.3. Buffs especiais

- **Guard / Protect** – redireciona parte do dano de um aliado para o usuário.  
- **HP Link** – compartilha danos entre aliados.  
- **Damage Reflection / Thorns** – reflete parte do dano recebido.  
- **Stealth / Invisibility** – dificulta ser alvo, aumenta dano/crit do próximo ataque.  
- **Cheat Death / Death Ward** – impede a morte uma vez (1 HP em vez de morrer).  
- **Self-Revive / Phoenix** – revive automaticamente ao morrer, com certa quantidade de HP.  
- **Transformation** – estado especial que aumenta vários atributos e pode liberar skills diferentes.  
- **SP Cost Down** – reduz custo de SP de certas habilidades.  
- **Próximo Ataque Fortalecido/Crítico Garantido** – buff consumido no próximo ataque/habilidade.

---

## 9. Equipamentos & Slots

### 9.1. Slots de equipamento (v1)

O personagem possui:

1. **Arma Principal**  
2. **Mão Secundária (Escudo ou Arma Secundária)**  
3. **Armor (Corpo)**  
4. **Leggins (Pernas)**  
5. **Item** (equipamento físico/utilitário adicional)  
6. **Magical Item** (anel, amuleto, relíquia, etc.)

### 9.2. Armas 1H / 2H e Off-hand

Na aba **LVL1**, as armas têm:

- Campo `Equip`:  
  - **1H** – arma de uma mão,  
  - **2H** – arma de duas mãos.

Regras:

- Arma **2H**:
  - ocupa as duas mãos,
  - bloqueia escudo e arma secundária.

- Arma **1H**:
  - ocupa apenas a mão principal,
  - permite:
    - **Escudo** na mão secundária,  
    - ou **arma secundária** (dual wield), se a arma for marcada como **Off-hand possível**.

Algumas armas 1H são marcadas como elegíveis para off-hand:
- Dagger, Shortsword, Sickle, Club leve, Handaxe, Light Hammer, Whip, Gauntlets, etc.

### 9.3. Dual Wield (Empunhadura Dupla)

- Dual wield = arma 1H na mão principal + arma 1H compatível na mão secundária.
- Regras gerais:
  - Ataques com a arma da mão secundária podem ter:
    - dano reduzido,
    - leve penalidade de precisão.
  - Sem escudo → menor defesa bruta, depende de evasão/cura.

Classes com maior sinergia natural:
- **Rogue (Male)** – principal arquétipo de dual wield (duas adagas, adaga+shortsword etc.).  
- **Berserker** – mais focado em duas armas pesadas/agressivas.  
- Outras classes **podem** usar dual wield, mas sem tantas vantagens nativas.

### 9.4. Armaduras por classe

Baseado na aba **Armor**:

- **Knight:** Plate  
- **Warrior:** Half Plate  
- **Berserker:** Half Plate  
- **Rogue (Male):** Studded Leather  
- **Ranger:** Studded Leather  
- **Druid:** Studded Leather  
- **Cleric:** Padded  
- **Shaman:** Padded  
- **Pyromancer:** Leather  
- **Cryomancer:** Leather  

Cada classe só pode equipar armaduras do seu tipo base, em qualquer raridade.

### 9.5. Slots Item e Magical Item

- **Item:**
  - botas especiais, capas, cintos, fragmentos de armadura,
  - itens físicos de calamidades (ex.: Fragmento de Vajra, Plumas de Vāyu, Véu de Apsara).

- **Magical Item:**
  - anéis (listados na FICHA),
  - amuletos,
  - gemas e relíquias mágicas (Ex.: Escama de Karkotaka, Colar dos Pretas Vorazes, Essência do Dragão Celestial, etc.).

---

## 10. Loot & Raridade

### 10.1. Filosofia

- Conteúdo fácil → loot simples.  
- Conteúdo difícil (dungeons avançadas, calamidades, raids, bosses) → loot realmente valioso.

### 10.2. Tiers de raridade (base LVL1 + Armor)

O jogo trabalha com **6 níveis de raridade**:

1. **Básico**  
2. **Comum**  
3. **Incomum**  
4. **Raro**  
5. **Lendário**  
6. **Mítico**

- **Básico:**  
  - Equipamentos iniciais/tutoriais, especialmente armaduras.  
- **Comum:**  
  - Armas e armaduras base, drop de monstros comuns, loot de early game.
- **Incomum:**  
  - Versões melhores de armas/armaduras iniciais, mini-bosses e dungeons fáceis.
- **Raro:**  
  - Conteúdo intermediário, mini-bosses, dungeons intermediárias.
- **Lendário:**  
  - Bosses importantes, late game, artefatos ligados à lore.
- **Mítico:**  
  - Endgame real: raids, calamidades de alto nível, conteúdo especial.

### 10.3. Itens e aba LVL1

- A aba **LVL1** mostra armas com raridades:
  - Comum, Incomum, Raro, Lendário, Mítico.
- A aba **Armor** mostra:
  - Básico, Comum, Incomum, Raro, Raro+ (Mítico), Raro++ (Lendário).

Na prática:

- O sistema interno usa:
  - Básico, Comum, Incomum, Raro, Lendário, Mítico.
- Rótulos como “Raro+ (Mítico)” e “Raro++ (Lendário)” ajudam a granular internamente, mas o jogador vê apenas a raridade principal.

### 10.4. Interação com “Find”

- **Gold Find:** mais ouro.  
- **Item Find:** mais itens/materiais (mais rolagens de loot).  
- **Magical Item Find:** maior chance de drop promosso para raridades maiores (Raro, Lendário, Mítico), em conteúdos onde isso é possível.

---

## 11. Criação de Personagem

### 11.1. Fluxo

1. Selecionar slot de personagem.
2. Escolher **Mono Classe** ou **Dual Classe**.
3. Escolher classe(s) entre as 10 iniciais.
4. Escolher **Background** (história de origem).
5. Aparência gerada automaticamente de acordo com classe/tipo de armadura.
6. Receber equipamento inicial base + ajustes do background.
7. Confirmar criação e iniciar na estrada que leva ao vilarejo.

### 11.2. Mono Classe vs Dual Classe

- **Mono Classe:**
  - Nível máximo 100.
  - Progressão mais simples, foco em uma árvore de classe.

- **Dual Classe:**
  - Nível máximo 180.
  - Combina duas árvores de classe, builds mais complexos.

Escolha é **permanente**.

---

## 12. Backgrounds

### 12.1. Ideia geral

- Substituem “raças/casas” como elemento jogável.
- São **genéricos**, para encaixar em múltiplas classes, e baseados nas perícias (Acrobatics, Arcana, etc.) da FICHA.
- Cada classe tem 3–4 backgrounds sugeridos, de acordo com seus pontos fortes de perícia.
- Personagens Dual Classe veem a **união** das opções das duas classes.

### 12.2. Lista de backgrounds (v1)

1. **Scholar (Erudito)** – estudo formal, livros, pesquisa.  
2. **Cultist (Cultista)** – seitas, segredos proibidos.  
3. **Acolyte (Acólito)** – devoção religiosa normal, templos.  
4. **Soldier (Soldado)** – exército, milícia, combate organizado.  
5. **Guardian (Guardião)** – guarda de cidade, escolta, proteção.  
6. **Outlander (Forasteiro das Terras Selvagens)** – vida na natureza, caçador.  
7. **Scout (Batedor)** – reconhecimento, infiltração, rastreamento.  
8. **Criminal (Criminoso)** – furtos, contrabando, malandragem.  
9. **Artisan (Artífice/Comerciante)** – ofício, comércio, investigação prática.  
10. **Performer (Artista)** – entretenimento, manipulação social.

### 12.3. Ligação com classes (exemplos)

- **Pyromancer:** Cultist, Scholar, Scout, Soldier.  
- **Cryomancer:** Cultist, Scholar, Scout, Acolyte.  
- **Knight:** Soldier, Guardian, Cultist, Scout.  
- **Warrior:** Soldier, Guardian, Scout, Cultist.  
- **Berserker:** Soldier, Guardian, Scout, Cultist.  
- **Rogue (Male):** Scout, Criminal, Performer, Cultist.  
- **Ranger:** Scout, Outlander, Guardian, Soldier.  
- **Druid:** Outlander, Scout, Acolyte, Cultist.  
- **Cleric:** Acolyte, Cultist, Artisan, Scout.  
- **Shaman:** Cultist, Acolyte, Outlander, Scout.

(**Dual Class:** soma das opções das duas classes.)

### 12.4. Efeitos de Background

- Ajusta **itens iniciais**:
  - mais/menos poções, munição, materiais, pequenas variações de equipamento.
- Define **afinidade com grupos de Common Passives**:
  - facilita acesso a certas passivas (custo reduzido, liberadas mais cedo),
  - pode conceder uma passiva de tier baixo logo no início.

---

## 13. Common Passives e Slot de Passiva

### 13.1. Common Passives

- Listadas em aba própria na FICHA, com:
  - **Escala** (1, 4, 6, 10, 14, …, 48),
  - Nome,
  - Efeito,
  - Afinidade de classes.
- Servem como passivas “globais”, não amarradas a uma única classe.

Exemplos:
- Instinto de Sobrevivência, Agilidade Natural, Marca da Experiência, Resiliência Anímica, Recuperação Tática, Olhar do Caçador, Ligação Elemental, Chama do Combate Prolongado, etc.

### 13.2. Slot único de passiva ativa

- O personagem pode **aprender várias passivas**:
  - de classe,  
  - Common Passives,  
  - (futuro) passivas de itens.
- Porém, só pode **equipar 1 passiva por vez**:
  - **Slot de Passiva Ativa (Slot P)**.
- Todas as passivas competem pelo Slot P, inclusive as de classe.

Regras:
- Troca de passiva só fora de combate.
- Background e classes influenciam **quais passivas são mais acessíveis**, mas não alteram o limite de 1 ativa.

---

## 14. História Inicial & Vilarejo

### 14.1. Estrada para a Vila

- Cena inicial:
  - Jogador entra por uma estrada ao sul da vila, com rio ao lado.
  - Monólogo inicial muda conforme o **Background**, explicando por que o personagem veio até ali (Soldier investigando caravanas, Scholar buscando anomalias mágicas, Outlander sentindo a floresta “errada”, etc.).

- Um **Jovem Guarda** com seu cão (morador da 4ª casa) aborda o jogador:
  - pergunta quem é e o que veio fazer,
  - a resposta varia com o Background (mas sempre leva a um encaminhamento para a líder da vila).

### 14.2. O Vilarejo Inicial

Possui 7 casas, uma praça e arredores:

1. **Casa do Lenhador (1ª casa)**  
   - Lenhador, esposa e filho mais novo.
   - Ajuda o jogador com pesca, lenha, recursos naturais.
   - Filha mais velha, **Rose**, está desaparecida.

2. **Casa de Rose (2ª casa)**  
   - Cheia de flores.
   - Vazia no começo (Rose sumida); a mãe rega as flores e sente a falta da filha.
   - Após salvar Rose, o jogador ganha acesso a quests de floricultura/artesanato.

3. **Casa Vazia (3ª casa)**  
   - Antigo lar de um grupo de aventureiros que nunca retornou.
   - 3 lápides próximas ao rio.
   - Com o tempo, o jogador pode liberar essa casa como moradia própria.

4. **Casa do Guarda Jovem (4ª casa)**  
   - Fica mais ao norte, separada do núcleo da vila.
   - Guarda jovem e inexperiente, herdeiro do posto do pai que desapareceu em missão com aventureiros.
   - Futuro aliado recrutável (classe base: Warrior → Knight/Ranger/Sentinel).

5. **Casa da Líder do Vilarejo (5ª casa)**  
   - Velha, viúva, sábia.
   - NPC central para lore da região e quests principais.

6. **Casa da Família da Líder (6ª casa)**  
   - Filho da líder, esposa e dois filhos pequenos.
   - Ensinam mineração, minério e forja ao jogador.

7. **Casa do Mercador (7ª casa)**  
   - Mercador gordinho e simpático, adora aventureiros.
   - Amor platônico por Rose; quer muito que ela volte à vila.
   - Loja principal de itens básicos.

### 14.3. Arredores da Vila

- **Norte:**
  - Trilha subindo a montanha.
  - Cachoeira e ponte bonita.
  - Ruínas de pedra servindo como esconderijo de goblinoides, scouts e lobos pequenos.

- **Oeste:**
  - Caminho para floresta densa (onde Rose foi vista pela última vez).
  - Insetos e criaturas da floresta.
  - Restos de fazendas, galinhas, porcos.
  - Mais adiante, um pântano com criaturas aquáticas e fantasmas.

### 14.4. Quest da Rose e Árvore Guardiã

- Rose coletava flores na floresta ao redor da vila.
- Ela foi chamada por fadas para tentar **curar a Árvore Guardiã**, que está enlouquecendo.
- O jogador:
  - investiga a floresta,
  - enfrenta criaturas progressivamente mais estranhas,
  - resolve um **puzzle** que abre acesso a uma região mágica com fadas e poltergeists.
- Lá, uma fada importante explica:
  - a Árvore Guardiã enlouqueceu,
  - elas chamaram Rose por causa de seu conhecimento de cultivo.
- O jogador ajuda Rose a preparar um remédio.
  - Antes de surtir efeito, a Árvore entra em loucura total e vira um **mini-boss**.
- Ao derrotar a árvore:
  - fadas ficam tristes pela perda,
  - mas plantam uma nova semente,
  - uma nova Árvore Guardiã irá crescer com o tempo.
- Após esse arco:
  - Rose retorna à vila,
  - novas quests são liberadas (floricultura, artesanato, relações com as fadas),
  - a praça passa a servir como ponto de **teleporte/waystone** após quest de teleporte.

---

## 15. Lore & Livro dos Contos

- O **“Livro dos 100 Contos”** existe como:
  - coleção de histórias antigas do mundo (contadas por anciãos de gerações passadas),
  - base de lore para eventos, calamidades e itens lendários.
- No jogo, ele pode funcionar como:
  - um **colecionável**, tipo “álbum de figurinhas”,
  - desbloqueado ao derrotar bosses, completar quests, explorar certas regiões.
- Itens lendários e míticos fazem referência a:
  - personagens,
  - eventos,
  - monstros,
  - e lugares descritos nesse Livro.
- A versão atual do livro será **reorganizada** para ficar menos confusa e mais bem conectada ao gameplay.

---

Este documento resume o estado atual do GDD em alto nível, consolidando:

- decisões de combate, classes, atributos, status,
- sistemas de loot, raridade e equipamentos,
- criação de personagem (classes + backgrounds + Common Passives),
- e o Ato 1 inicial no vilarejo, com a quest da Rose e da Árvore Guardiã.

Detalhamentos numéricos específicos (fórmulas, valores exatos de dano, custos) permanecem dentro da FICHA RPG e podem ser conectados ponto a ponto com este GDD conforme o desenvolvimento avança.
